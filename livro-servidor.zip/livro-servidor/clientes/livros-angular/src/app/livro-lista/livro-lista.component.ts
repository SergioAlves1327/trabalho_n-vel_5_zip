import { Component, inject } from '@angular/core';
import { Editora } from '../editora';
import { Livro } from '../livro';
import { ControleEditoraService } from '../controle-editora.service';
import { ControleLivrosService } from '../controle-livros.service';

@Component({
  selector: 'app-livro-lista',
  templateUrl: './livro-lista.component.html',
  styleUrls: ['./livro-lista.component.css'],
})
export class LivroListaComponent {
  public editoras: Editora[] = [];
  public livros: Livro[] = [];
  private servEditora: ControleEditoraService = inject(ControleEditoraService);
  private servLivros: ControleLivrosService = inject(ControleLivrosService);

  ngOnInit() {
    this.editoras = this.servEditora.getEditoras();
    this.servLivros.obterLivros().then((livros) => {
      this.livros = livros;
    });
  }

  excluir = (codigo: string) => {
    this.servLivros.excluir(codigo);
    this.servLivros.obterLivros().then((livros) => {
      this.livros = livros;
    });
  };

  obterNome = (codEditora: number) => {
    return this.servEditora.getNomeEditora(codEditora);
  };
}
