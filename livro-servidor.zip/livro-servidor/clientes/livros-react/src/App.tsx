import "./App.css";
import LivroLista from "./LivroLista";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import LivroDados from "./LivroDados";

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item active">
              <a className="nav-link" href="/">
                Catálogo
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="/dados">
                Novo
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<LivroLista />} />
        <Route path="/dados" element={<LivroDados />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
