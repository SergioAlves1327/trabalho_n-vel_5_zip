var express = require('express');
var router = express.Router();

const { 
    excluir, 
    incluir,
    obterLivros 
} = require('../modelo/livro-dao')

router.get('/', async function(req, res, next) {
    try {
        const livros = await obterLivros();
        res.json(livros);
    } catch (error) {
        res.status(500).json({ erro: error.message });
    }
});

router.post('/', async function(req, res, next) {
    try {
        await incluir(req.body);
        res.status(201).json(req.body);
    } catch (error) {
        res.status(500).json({ erro: error.message });
    }
});

router.delete('/:_id', async function(req, res, next) {
    try {
        await excluir(req.params._id);
        res.status(204).end();
    } catch (error) {
        res.status(500).json({ erro: error.message });
    }
});

module.exports = router;